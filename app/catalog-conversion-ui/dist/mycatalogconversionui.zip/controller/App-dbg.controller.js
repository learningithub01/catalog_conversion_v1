sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("my.catalogconversionui.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  